export const environment = {
  firebase: {
    projectId: 'clicksperdido',
    appId: '1:835168344428:web:20ea8e3010e8ace9abfb49',
    storageBucket: 'clicksperdido.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyA1Cde-K88iqcW89eCxSWqLWt1YGuQsr0w',
    authDomain: 'clicksperdido.firebaseapp.com',
    messagingSenderId: '835168344428',
    measurementId: 'G-BPFGKSFEPJ',
  },
  production: true
};
