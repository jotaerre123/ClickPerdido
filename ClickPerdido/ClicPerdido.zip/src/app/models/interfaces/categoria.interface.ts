export interface Categorias{
    id: string;
    name: string;
}