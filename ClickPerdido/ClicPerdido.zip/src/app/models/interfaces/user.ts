export interface User {
    name: string;
    email: string;
    uid: string;
    photo: string;
}