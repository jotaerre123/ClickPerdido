export default class ListaFirebaseDto {
    id?: string;
    name?: string;
  }